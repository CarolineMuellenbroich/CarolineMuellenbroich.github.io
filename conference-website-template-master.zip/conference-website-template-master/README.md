# Academic Conference Website Template

A template website for a (small) academic conference. You can [explore a live version of the website here](https://mikepierce.github.io/conference-website-template/).

![Screenshot of the Website](https://raw.githubusercontent.com/mikepierce/conference-website-template/master/screenshot.png)

